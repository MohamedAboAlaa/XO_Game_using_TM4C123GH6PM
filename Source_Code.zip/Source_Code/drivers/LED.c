/******************************************************************************
 * Module: LED
 *
 * File Name: LED.c
 *
 * Description: Source file for LED
 *
 * Authors: El-Osood El-Mefrhda
 ******************************************************************************/

#include "..\\./headers/LED.h"

int i;
/*******************************************************************************
 *                           Functions                                     		 *
 *******************************************************************************/

void Set_Led_Pin(void)
{
	GPIO_PORTB_DATA_R |= (1 << PORTB_LED1_PIN); // PB2
	Timer2_delay_ms(500);
	GPIO_PORTB_DATA_R |= (1 << PORTB_LED2_PIN); // PB3
	Timer2_delay_ms(500);
	GPIO_PORTB_DATA_R |= (1 << PORTB_LED3_PIN); // PB4
}
void Set_Led_2(void)
{
	GPIO_PORTB_DATA_R |= (1 << PORTB_LED2_PIN); // PB3
}
void Clear_Led_2(void)
{
	GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED2_PIN); // PB3
}

void Set_Led_3(void)
{
	GPIO_PORTB_DATA_R |= (1 << PORTB_LED3_PIN); // PB4
}

void Clear_Led_3(void)
{
	GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED3_PIN); // PB4
}

void Clear_Led_Pin(void)
{
	GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED1_PIN); // PB2
	GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED2_PIN); // PB3
	GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED3_PIN); // PB4
}


void Blink_LEDS(void)
{
	for (i = 0; i < 3; i++)
	{
		GPIO_PORTB_DATA_R |= (1 << PORTB_LED1_PIN); // PB2
		Timer2_delay_ms(100);
		GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED1_PIN); // PB2
		Timer2_delay_ms(100);
	}
}

void Blink_LEDS_2(void)
{
	for (i = 0; i < 3; i++)
	{
		GPIO_PORTB_DATA_R |= (1 << PORTB_LED2_PIN); // PB3
		Timer2_delay_ms(100);
		GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED2_PIN); // PB3
		Timer2_delay_ms(100);
	}
}
void Blink_LEDS_3(void)
{
	for (i = 0; i < 3; i++)
	{
		GPIO_PORTB_DATA_R |= (1 << PORTB_LED3_PIN); // PB4
		Timer2_delay_ms(100);
		GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED3_PIN); // PB4
		Timer2_delay_ms(100);
	}
}
