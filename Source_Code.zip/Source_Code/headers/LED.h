/******************************************************************************
 * Module: LED
 *
 * File Name: LED.h
 *
 * Description: Header file for LED control functions.
 * 
 * Author: El-Osood El-Mefrhda
 ******************************************************************************/

#ifndef LED_H_
#define LED_H_

/*******************************************************************************
 *                      Included Libraries                                     *
 *******************************************************************************/

#include "..\\./headers/tm4c123gh6pm.h"
#include "..\\./headers/Timer.h"

/*******************************************************************************
 *                      LED Pin Definitions                                    *
 *******************************************************************************/

/** LED1 Pin on Port B */
#define PORTB_LED1_PIN  2

/** LED2 Pin on Port B */
#define PORTB_LED2_PIN  3

/** LED3 Pin on Port B */
#define PORTB_LED3_PIN  4

/*******************************************************************************
 *                      Function Prototypes                                    *
 *******************************************************************************/

void Set_Led_Pin(void);

void Set_Led_2(void);

void Set_Led_3(void);

void Clear_Led_2(void);

void Clear_Led_3(void);

void Clear_Led_Pin(void);

void Blink_LEDS_3(void);

void Blink_LEDS(void);

void Blink_LEDS_2(void);

#endif /* LED_H_ */
