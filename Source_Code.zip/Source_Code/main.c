/******************************************************************************
 * Module: Main File
 *
 * File Name: Main.c
 *
 * Description: Main file for initializing peripherals and running the XO game.
 *
 * Authors: El-Osood El-Mefrhda
 ******************************************************************************/

/*******************************************************************************
 *                       Headers                             * 
 *******************************************************************************/ 

#include "headers/tm4c123gh6pm.h"
#include "headers/Nokia5110.h"
#include "headers/TExaS.h"
#include "headers/GPIO.h"
#include "headers/XO Game.h"
#include "headers/PLL.h"
#include "headers/ADC.h"
#include "headers/UART.h"
#include "headers/Timer.h"

/*******************************************************************************
 *                          Functions                             *
 *******************************************************************************/

/**
 * @brief Main function that initializes all modules and runs the XO game.
 * @param None
 * @return int: Exit status of the program (default is 0)
 */
int main(void)
{
    TExaS_Init(SSI0_Real_Nokia5110_Scope); // Initialize scope for debugging

    ADC0_InitSWTriggerSeq3_Ch0();          // Initialize ADC for PE3 input

    PortF_Init();                          // Initialize Port F

		PortD_Init();                          // Initialize Port D
	
    UART_Init();                           // Initialize UART

    Nokia5110_Init();                      // Initialize Nokia LCD

    Nokia5110_ClearBuffer();               // Clear Nokia LCD buffer

    Nokia5110_DisplayBuffer();             // Display initial buffer

    GameIntro();                           // Display game introduction

    PlayXO();                              // Start the XO game

    return 0;                              // Program exit status
}
